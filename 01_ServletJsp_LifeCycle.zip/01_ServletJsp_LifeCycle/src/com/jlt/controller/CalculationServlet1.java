package com.jlt.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CalculationServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public CalculationServlet1() {
        super();
        
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		int num1=Integer.valueOf(request.getParameter("txtnum1"));
		int num2=Integer.valueOf(request.getParameter("txtnum2"));
		String option=request.getParameter("option");
		
		
		PrintWriter out=response.getWriter();
		
		switch(option)
		{
		case "+":
			out.println("Addition of "+ num1+"and"+num2+"is"+(num1+num2));
			break;
		case "-":
			out.println("substraction of "+ num1+"and"+num2+"is"+(num1-num2));
			break;
		case "*":
			out.println("multiplication of "+ num1+"and"+num2+"is"+(num1*num2));
            break;
		case "/":
			out.println("Division of "+ num1+"and"+num2+"is"+(num1/num2));
			break;


		}
		
		
	}

}

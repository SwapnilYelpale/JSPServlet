package com.jlt.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class EmployeeDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public EmployeeDetailsServlet() {
        super();
        
    }

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int employeeID=Integer.valueOf(request.getParameter("txtEmployeeID"));
		String name=request.getParameter("txtname");
		double Salary=Double.valueOf(request.getParameter("txtSalary"));
		
		PrintWriter out=response.getWriter();
		out.println("EmployeeId::"+employeeID);
		out.println("Name::"+name);
		out.println("Salary::"+Salary);
	}
}
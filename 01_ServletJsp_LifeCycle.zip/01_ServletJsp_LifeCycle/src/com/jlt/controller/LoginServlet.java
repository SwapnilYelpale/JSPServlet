package com.jlt.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LoginServlet() {
        super();
        
    }

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int userid=Integer.valueOf(request.getParameter("txtuserID"));
		int password =Integer.valueOf(request.getParameter("password"));
		
		if(userid==123&&password==123)
		{
			response.sendRedirect("Calculation.html");
			
		}else {
			response.sendRedirect("login.html");

			
		}
		
	}

}
